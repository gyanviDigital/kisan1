<!DOCTYPE html>
 <html lang="en">
<head>
    <link rel="canonical" href="https://www.kisantractoryojana.in/" />
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kisan Tractor Yojana    </title>

    <!-- Meta SEO -->
    <meta name="title" content="Kisan Tractor Yojana">
    <meta name="description" content="Kisan Tractor Yojana">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="language" content="English">
    <meta name="author" content="kisantractoryojana">

    <!-- Social media share -->
    <meta property="og:title" content="Kisan Tractor Yojana">
    <meta property="og:site_name" content="kisantractoryojana">
    <meta property="og:url" content="https://www.kisantractoryojana.in/">
    <meta property="og:description" content="Kisan Tractor Yojana">
    <meta property="og:type" content="">
    <meta property="og:image" content="https://www.kisantractoryojana.in/public/home/images/logo.jpg">
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@kisantractoryojana" />
    <meta name="twitter:creator" content="@kisantractoryojana" />

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="https://www.kisantractoryojana.in/public/home/images/logo.jpg">
    <link rel="icon" type="image/png" sizes="32x32" href="https://www.kisantractoryojana.in/public/home/images/logo.jpg">
    <link rel="icon" type="image/png" sizes="16x16" href="https://www.kisantractoryojana.in/public/home/images/logo.jpg">
    <link rel="manifest" href="/site.webmanifest">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <link href="https://www.kisantractoryojana.in/public/home/output.css" rel="stylesheet">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    
   
</head>        
<style>
    .bg-purple-700 {
      background-color: orange;
    }
  </style>
  <!-- Google tag (gtag.js) -->

  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'AW-16545453419');
  </script>
</head>

<style>
    .logo img {
    height: 67px;
}
 .logo-right img {
    height: 67px;
    float: right;
}
header {
    /* padding: 10px; */
    border-bottom: 5px solid #a5cf45;
    margin: 0 0 5px 0;
}

</style>
<body>


                <header class="fixed w-full">
    <nav class="bg-white border-gray-200 py-2.5 dark:bg-gray-900">
      <div class="flex flex-wrap items-center justify-between max-w-screen-xl px-4 mx-auto">
        <a href="#" class="flex items-center">
          <img src="https://www.kisantractoryojana.in/public/home/images/logo.jpg" class="" alt="Kisan Tractor Yojana" width="105" height="65">
          <span class="self-center text-xl font-semi"></span>
        </a>
        <div class="flex items-center lg:order-2">
          <div class="hidden mt-2 mr-4 sm:inline-block">

          </div>
         


                                  <a href="https://www.kisantractoryojana.in/register" class="text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 sm:mr-2 lg:mr-0 dark:bg-purple-600 dark:hover:bg-purple-700 focus:outline-none dark:focus:ring-purple-800">Apply Now</a>
                    <button data-collapse-toggle="mobile-menu-2" type="button" class="inline-flex items-center p-2 ml-1 text-sm text-gray-500 rounded-lg lg:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="mobile-menu-2" aria-expanded="false">
                       
                    </button>&nbsp;&nbsp;&nbsp;
                    <a href="https://www.kisantractoryojana.in/login" class="text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 sm:mr-2 lg:mr-0 dark:bg-purple-600 dark:hover:bg-purple-700 focus:outline-none dark:focus:ring-purple-800" style="
    background: green;
">Login</a>
                        


          <button data-collapse-toggle="mobile-menu-2" type="button" class="inline-flex items-center p-2 ml-1 text-sm text-gray-500 rounded-lg lg:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="mobile-menu-2" aria-expanded="false">
            <span class="sr-only">Open main menu</span>
            <svg class="w-6 h-6" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path>
            </svg>
            <svg class="hidden w-6 h-6" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
            </svg>
          </button>
        </div>
        <div class="items-center justify-between hidden w-full lg:flex lg:w-auto lg:order-1" id="mobile-menu-2">
          <img src="https://www.kisantractoryojana.in/public/home/images/azadikaamritmahotsav.jpg" alt="Girl in a jacket" width="90" height="100">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <ul class="flex flex-col mt-4 font-medium lg:flex-row lg:space-x-8 lg:mt-0">
            <li>
              <a href="#" class="block py-2 pl-3 pr-4 text-white rounded lg:bg-transparent lg:text-purple-700 lg:p-0 dark:text-white" aria-current="page">Home</a>
            </li>
            <li>
              <a href="#brands" class="block py-2 pl-3 pr-4 text-gray-700 border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-purple-700 lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700">Features Brands</a>
            </li>
            <li>
              <a href="#about" class="block py-2 pl-3 pr-4 text-gray-700 border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-purple-700 lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700">About Us</a>
            </li>
            <li>
              <a href="#howitwork" class="block py-2 pl-3 pr-4 text-gray-700 border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-purple-700 lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700">How it work</a>
            </li>
            <li>
              <a href="#privacy" class="block py-2 pl-3 pr-4 text-gray-700 border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-purple-700 lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700">Privacy Policy</a>
            </li>
            <li>
              <a href="#contact" class="block py-2 pl-3 pr-4 text-gray-700 border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-purple-700 lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700">Contact</a>
            </li>
            <li>
              <a href="#faq" class="block py-2 pl-3 pr-4 text-gray-700 border-b border-gray-100 hover:bg-gray-50 lg:hover:bg-transparent lg:border-0 lg:hover:text-purple-700 lg:p-0 dark:text-gray-400 lg:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white lg:dark:hover:bg-transparent dark:border-gray-700">FAQ</a>
            </li>

          </ul>
        </div>
      </div>
    </nav>
  </header>
            
  <style>
    .text-purple-500 {
    --tw-text-opacity: 1;
    color: rgb(11 105 61);
}
  </style>        <style>
  @media (max-width: 480px) {
    .costum_margin{
      margin-top: 66px;
}
}


</style>


  <!-- Start block -->
  <section class="bg-white dark:bg-gray-900">
    <div class="grid max-w-screen-xl px-4 pt-20 pb-8 mx-auto lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-12 lg:pt-28">
      <div class="mr-auto place-self-center lg:col-span-7 costum_margin">
        <h4 class="max-w-2xl mb-6 text-4xl font-extrabold leading-none tracking-tight md:text-5xl xl:text-6xl dark:text-white">Kisan Tractor Yojana </h4>
        <p class="max-w-2xl mb-6 font-light text-gray-500 lg:mb-8 md:text-lg lg:text-xl dark:text-gray-400">A tractor plays a vital role in a farmer's life, and due to its high prices, not every farmer can afford it. Considering this matter, the central government has announced the Kisan Tractor Yojana 2024, under which the Indian farmers can get a 50% subsidy on buying tractors. Under this, a beneficiary can apply for the scheme, and the R.O (Release order) will send to nearby dealer on the behalf of farmer. The scheme is already running successfully. An individual who fulfills all the eligibility requirements can avail of the benefits.</p>

        <div class="space-y-4 sm:flex sm:space-y-0 sm:space-x-4">
          <a href="https://www.kisantractoryojana.in/register" style="background-color: green;
    color: white;" class="inline-flex items-center justify-center w-full px-5 py-3 text-sm font-medium text-center text-gray-900 border border-gray-200 rounded-lg sm:w-auto hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 dark:text-white dark:border-gray-700 dark:hover:bg-gray-700 dark:focus:ring-gray-800">
            Register Now <img src="https://www.kisantractoryojana.in/public/home/new-flash-gif.gif" alt="new" width="30" height="30">
          </a>
          <a href="https://www.kisantractoryojana.in/login" style="background-color: green;
    color: white;" class="inline-flex items-center justify-center w-full px-5 py-3 text-sm font-medium text-center text-gray-900 border border-gray-200 rounded-lg sm:w-auto hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 dark:text-white dark:border-gray-700 dark:hover:bg-gray-700 dark:focus:ring-gray-800">
            Check Your Status <img src="https://www.kisantractoryojana.in/public/home/new-flash-gif.gif" alt="new" width="30" height="30">
          </a>
          
        </div>
      </div>
      <div class="lg:mt-0 lg:col-span-5 lg:flex">
        <img src="https://www.kisantractoryojana.in/public/home/images/hero.png" alt="hero image">
      </div>
    </div>
  </section>

  <!-- End block -->
  <!-- Start block -->
  <section id="brands">
    <section class="bg-white dark:bg-gray-900">

      <div class="max-w-screen-xl px-4 pb-8 mx-auto lg:pb-16">
        <b>
          <h3>Features Brands you may Apply</h3>
        </b>
        <div class="grid grid-cols-2 gap-8 text-gray-500 sm:gap-12 sm:grid-cols-3 lg:grid-cols-6 dark:text-gray-400">

          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">

            <img src="https://www.kisantractoryojana.in/public/home/images/1.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/2.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/3.png" alt="Girl in a jacket" width="100" height="100">

          </a>

          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/4.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/5.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/6.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/7.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/8.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/9.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/10.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/11.png" alt="Girl in a jacket" width="100" height="100">

          </a>
          <a href="https://www.kisantractoryojana.in/register" class="flex items-center lg:justify-center">
            <img src="https://www.kisantractoryojana.in/public/home/images/12.png" alt="Girl in a jacket" width="100" height="100">

          </a>
        </div>
      </div>
    </section>
    <!-- End block -->
    <!-- Start block -->
    <section id="about">
      <section class="bg-gray-50 dark:bg-gray-800">
        <div class="max-w-screen-xl px-4 py-8 mx-auto space-y-12 lg:space-y-20 lg:py-24 lg:px-6">
          <!-- Row -->
          <div class="items-center gap-8 lg:grid lg:grid-cols-2 xl:gap-16">
            <div class="text-gray-500 sm:text-lg dark:text-gray-400">
              <h2 class="mb-4 text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white">About Kisan Tractor Yojana</h2>
              <h3 style="text-align: left;">Welcome To <span id="W_Name1">Kisan Tractor Yojana Portal</span></h3>
              <p><span id="W_Name2">This</span> is a Professional <span id="W_Type1">tractor subsidy yojana </span> Platform. Here we will provide you full information and process to avail the subsidy on the purchase of tractor, which you will like very much. We're dedicated to providing you the best services to avail <span id="W_Type2">subsidy on tractor purchase.</span>, with a focus on dependability and <span id="W_Spec">tractor subsidy yojana</span>. We're the only authroize agency who deal with <span id="W_Type3">tractor subsidy yojana</span> We hope you enjoy our <span id="W_Type4">services</span> as much as we enjoy offering them to you.</p>
              <!-- List -->

              <ul role="list" class="pt-8 space-y-5 border-t border-gray-200 my-7 dark:border-gray-700">
                <b>Important Guideline</b>
                <li class="flex space-x-3">
                  <!-- Icon -->
                  <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                  </svg>
                  <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Today is the last date to process your Application Form. </span>
                </li>
                <li class="flex space-x-3">
                  <!-- Icon -->
                  <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                  </svg>
                  <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Final R.O will be Released tills 31 Dec. 2024.</span>
                </li>
                <li class="flex space-x-3">
                  <!-- Icon -->
                  <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                  </svg>
                  <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Any Farmer From GENERAL/OBC/SC/ST can Apply</span>
                </li>
                <li class="flex space-x-3">
                  <!-- Icon -->
                  <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                  </svg>
                  <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Make Sure submit your Refundable Application Fee with in 24 Hours from the Time of Registration.</span>
                </li>

              </ul>


            </div>
            <img class="hidden w-full mb-4 rounded-lg lg:mb-0 lg:flex" src="https://www.kisantractoryojana.in/public/home/images/kisantractoryojana.png" alt="dashboard feature image">
          </div>
          <!-- Row -->
          <div id="howitwork">
            <div class="items-center gap-8 lg:grid lg:grid-cols-2 xl:gap-16">
              <img class="hidden w-full mb-4 rounded-lg lg:mb-0 lg:flex" src="https://www.kisantractoryojana.in/public/home/images/howitwork.png" alt="feature image 2">
              <div class="text-gray-500 sm:text-lg dark:text-gray-400">
                <h2 class="mb-4 text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white">How Application Process Work</h2>
                <p class="mb-8 font-light lg:text-xl">Once you will registered for Subsidy under Kisan Tractor Yojana Subsidy your Application process as below.</p>
                <!-- List -->
                <ul role="list" class="pt-8 space-y-5 border-t border-gray-200 my-7 dark:border-gray-700">
                  <li class="flex space-x-3">
                    <!-- Icon -->
                    <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                    </svg>
                    <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Visit official Portal Info@kisantractoryojana.in</span>
                  </li>
                  <li class="flex space-x-3">
                    <!-- Icon -->
                    <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                    </svg>
                    <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Click On Apply Now</span>
                  </li>
                  <li class="flex space-x-3">
                    <!-- Icon -->
                    <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                    </svg>
                    <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Select your residence Address</span>
                  </li>
                  <li class="flex space-x-3">
                    <!-- Icon -->
                    <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                    </svg>
                    <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Choose Tractor Brand and Apply</span>
                  </li>
                  <li class="flex space-x-3">
                    <!-- Icon -->
                    <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                    </svg>
                    <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Submit your Refundable Application Fee & NOC Fee</span>
                  </li>
                </ul>
                <p class="font-light lg:text-xl"><b>Wait For R.O it may take 10-15 working day for Final Process.</b>.</p>
              </div>

            </div>
            <div id="privacy">
              <div class="max-w-screen-xl px-4 py-8 mx-auto space-y-12 lg:space-y-20 lg:py-24 lg:px-6">
                <!-- Row -->
                <div class="items-center gap-8 lg:grid lg:grid-cols-2 xl:gap-16">
                  <div class="text-gray-500 sm:text-lg dark:text-gray-400">
                    <h2 class="mb-4 text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white">Privacy Policy</h2>
                    <h3 style="text-align: left;">Welcome To <span id="W_Name1">Kisan Tractor Yojana Portal</span></h3>
                    <p>Your Personal Information including Your name, age, address, email id, phone number, date of birth, gender, address, any other sensitive personal data or information etc. We may receive Your Information from third parties such as social media, and in such case, the information We collect may include your user name associated with that social media, any information or content the social media has the right to share with us, such as your profile picture, email address or friends list, and any information you have made public in connection with that social media. When you access the Website or otherwise deal with any Kisan Tractor Yojana entity through social media, you are authorizing Kisan Tractor Yojana to collect, store, use and retain such information and content in accordance with the terms of this Privacy Policy.</p>


                  </div>
                  <img class="hidden w-full mb-4 rounded-lg lg:mb-0 lg:flex" src="https://www.kisantractoryojana.in/public/home/images/privacy_policy_hero.png" alt="dashboard feature image">
                </div>
                <div id="contact">
                  <div class="items-center gap-8 lg:grid lg:grid-cols-2 xl:gap-16">
                    <img class="hidden w-full mb-4 rounded-lg lg:mb-0 lg:flex" src="https://www.kisantractoryojana.in/public/home/images/contact.png" alt="feature image 2">
                    <div class="text-gray-500 sm:text-lg dark:text-gray-400">
                      <h2 class="mb-4 text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white">Contact Us</h2>
                      <p class="mb-8 font-light lg:text-xl">You may contact to Given Email for any Assistance.</p>
                      <!-- List -->
                      <ul role="list" class="pt-8 space-y-5 border-t border-gray-200 my-7 dark:border-gray-700">
                        <li class="flex space-x-3">
                          <!-- Icon -->
                          <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                          <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Write us to <a href="cdn-cgi/l/email-protection.html#0c65626a634c67657f6d62787e6d6f78637e756366626d226562"> <span class="__cf_email__" data-cfemail="dfb6b1b9b09fb4b6acbeb1abadbebcabb0ada6b0b5b1bef1b6b1">[email&#160;protected]</span></a></span>
                        </li>
                        <li class="flex space-x-3">
                          <!-- Icon -->
                          <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                          <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Working Hours Monday to Friday Morning 10:00 to Evening 05:00.</span>
                        </li>
                        <li class="flex space-x-3">
                          <!-- Icon -->
                          <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                          <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">
                            Help Desk:- 18001202466 , 022-50647260
                            10AM to 5 PM
                          </span>
                        </li>
                        <li class="flex space-x-3">
                          <!-- Icon -->
                          <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                          <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">Registered Address:-</span>
                        </li>
                        <li class="flex space-x-3">
                          <!-- Icon -->
                          <svg class="flex-shrink-0 w-5 h-5 text-purple-500 dark:text-purple-400" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                          <span class="text-base font-medium leading-tight text-gray-900 dark:text-white">69A, Hanuman Road, Vile Parle East, Mumbai 400057.</span>
                        </li>
                      </ul>
                      <p class="font-light lg:text-xl"><b>Wait For R.O it may take 10-15 working day for Final Process.</b>.</p>
                    </div>

                  </div>


                  <!-- End block -->
                  <!-- Start block -->
                  <!-- End block -->
                  <!-- Start block -->
                  <section class="bg-gray-50 dark:bg-gray-800">
                    <div class="max-w-screen-xl px-4 py-8 mx-auto text-center lg:py-24 lg:px-6">
                      <figure class="max-w-screen-md mx-auto">
                        <svg class="h-12 mx-auto mb-3 text-gray-400 dark:text-gray-600" viewbox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M14.017 18L14.017 10.609C14.017 4.905 17.748 1.039 23 0L23.995 2.151C21.563 3.068 20 5.789 20 8H24V18H14.017ZM0 18V10.609C0 4.905 3.748 1.038 9 0L9.996 2.151C7.563 3.068 6 5.789 6 8H9.983L9.983 18L0 18Z" fill="currentColor"></path>
                        </svg>
                        <blockquote>
                          <p class="text-xl font-medium text-gray-900 md:text-2xl dark:text-white">" आज मेरा ट्रेक्टर मुझे मिल गया मैं सरकार का बहुत ही आभारी हूँ की आज मुझ जैसे गरीब किसान को भी ट्रेक्टर लेने का सपना पूरा हो रहा है."</p>
                        </blockquote>
                        <figcaption class="flex items-center justify-center mt-6 space-x-3">
                          <img class="w-6 h-6 rounded-full" src="https://www.kisantractoryojana.in/public/home/images/punia.jpg" alt="profile picture">
                          <div class="flex items-center divide-x-2 divide-gray-500 dark:divide-gray-700">
                            <div class="pr-3 font-medium text-gray-900 dark:text-white">Sunil Punia</div>
                            <div class="pl-3 text-sm font-light text-gray-500 dark:text-gray-400">Farmer</div>
                          </div>
                        </figcaption>
                      </figure>
                    </div>
                  </section>
                  <!-- End block -->
                  <!-- Start block -->
                  <!-- End block -->
                  <!-- Start block -->
                  <section id="faq">
                    <section class="bg-white dark:bg-gray-900">
                      <div class="max-w-screen-xl px-4 pb-8 mx-auto lg:pb-24 lg:px-6 ">
                        <h2 class="mb-6 text-3xl font-extrabold tracking-tight text-center text-gray-900 lg:mb-8 lg:text-3xl dark:text-white">Frequently asked questions</h2>
                        <div class="max-w-screen-md mx-auto">
                          <div id="accordion-flush" data-accordion="collapse" data-active-classes="bg-white dark:bg-gray-900 text-gray-900 dark:text-white" data-inactive-classes="text-gray-500 dark:text-gray-400">
                            <h3 id="accordion-flush-heading-1">
                              <button type="button" class="flex items-center justify-between w-full py-5 font-medium text-left text-gray-900 bg-white border-b border-gray-200 dark:border-gray-700 dark:bg-gray-900 dark:text-white" data-accordion-target="#accordion-flush-body-1" aria-expanded="true" aria-controls="accordion-flush-body-1">
                                <span>What is the Kisan Tractor Yojana?</span>
                                <svg data-accordion-icon="" class="w-6 h-6 rotate-180 shrink-0" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                  <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                </svg>
                              </button>
                            </h3>
                            <div id="accordion-flush-body-1" class="" aria-labelledby="accordion-flush-heading-1">
                              <div class="py-5 border-b border-gray-200 dark:border-gray-700">
                                <p class="mb-2 text-gray-500 dark:text-gray-400">The Kisan Tractor Yojana is a government initiative aimed at providing subsidies to farmers for the purchase of tractors, with the goal of enhancing agricultural productivity and easing the burden of manual labor.</p>

                              </div>
                            </div>
                            <h3 id="accordion-flush-heading-2">
                              <button type="button" class="flex items-center justify-between w-full py-5 font-medium text-left text-gray-500 border-b border-gray-200 dark:border-gray-700 dark:text-gray-400" data-accordion-target="#accordion-flush-body-2" aria-expanded="false" aria-controls="accordion-flush-body-2">
                                <span>How much Subsidy i will got?</span>
                                <svg data-accordion-icon="" class="w-6 h-6 shrink-0" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                  <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                </svg>
                              </button>
                            </h3>
                            <div id="accordion-flush-body-2" class="hidden" aria-labelledby="accordion-flush-heading-2">
                              <div class="py-5 border-b border-gray-200 dark:border-gray-700">
                                <p class="mb-2 text-gray-500 dark:text-gray-400">You will got maximum up to 50% of on Road Price of the tractor.</p>

                              </div>
                            </div>
                            <h3 id="accordion-flush-heading-3">
                              <button type="button" class="flex items-center justify-between w-full py-5 font-medium text-left text-gray-500 border-b border-gray-200 dark:border-gray-700 dark:text-gray-400" data-accordion-target="#accordion-flush-body-3" aria-expanded="false" aria-controls="accordion-flush-body-3">
                                <span>Is any Application Fee is Required for Process the Application?</span>
                                <svg data-accordion-icon="" class="w-6 h-6 shrink-0" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                  <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                </svg>
                              </button>
                            </h3>
                            <div id="accordion-flush-body-3" class="hidden" aria-labelledby="accordion-flush-heading-3">
                              <div class="py-5 border-b border-gray-200 dark:border-gray-700">
                                <p class="mb-2 text-gray-500 dark:text-gray-400">Yes Refundable Application Fee and NOC Fee is Required for Process the Application</p>
                                <p class="mb-2 text-gray-500 dark:text-gray-400">Applicant can Process the fee as per their category that is under mention</p>

                                <ul class="pl-5 text-gray-500 list-disc dark:text-gray-400">
                                  <li><a href="#" class="text-purple-600 dark:text-purple-500 hover:underline">Genral :- Rs.5500/-</a></li>
                                  <li><a href="#" class="text-purple-600 dark:text-purple-500 hover:underline">OBC :- Rs.5200/-</a></li>
                                  <li><a href="#" class="text-purple-600 dark:text-purple-500 hover:underline">SC/ST :- Rs.5000/-</a></li>
                                  <li><a href="#" class="text-purple-600 dark:text-purple-500 hover:underline">X-Service Men :- Rs.5000/-</a></li>
                                </ul>
                                <p class="mb-2 text-gray-500 dark:text-gray-400">Note:- NOC Fee Rs.25000/- is applicable for all category.</p>
                              </div>
                            </div>
                            <h3 id="accordion-flush-heading-4">
                              <button type="button" class="flex items-center justify-between w-full py-5 font-medium text-left text-gray-500 border-b border-gray-200 dark:border-gray-700 dark:text-gray-400" data-accordion-target="#accordion-flush-body-4" aria-expanded="false" aria-controls="accordion-flush-body-4">
                                <span>is this fee is Refundable?</span>
                                <svg data-accordion-icon="" class="w-6 h-6 shrink-0" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                  <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                </svg>
                              </button>
                            </h3>
                            <div id="accordion-flush-body-4" class="hidden" aria-labelledby="accordion-flush-heading-4">
                              <div class="py-5 border-b border-gray-200 dark:border-gray-700">
                                <p class="mb-2 text-gray-500 dark:text-gray-400">Yes this fee is Refundable.</p>
                                <p class="mb-2 text-gray-500 dark:text-gray-400">However, If you have applied you may 100% got the subsidy but if due to any reasons if the application may be turn down then you will got 100% refund.</p>


                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    


                      <center>
                        <p>© 2021-2024 Kisan Tractor Yojana ™. All Rights Reserved. </p><span><img src="https://www.kisantractoryojana.in/public/home/images/azadikaamritmahotsav.jpg" alt="Kisan Tractor Yojana" width="100" height="100"></span>
                      </center>
                    </section>
                    <!-- End block -->
                                        <div class="fix-icon-whataap">
                      <div id="fix-icon-whataap" class="fix-icon-whataap-item">
                        <a href="https://api.whatsapp.com/send?phone=+917002867678&amp;text=Hi" target=_blank>
                          <img src="https://www.kisantractoryojana.in/public/home/assets/images/whatsapp.svg" alt=Whatsapp>
                        </a>
                      </div>
                    </div>


                    <a href="https://www.kisantractoryojana.in/register" class="float" target="_blank">
                      <img src="https://www.kisantractoryojana.in/public/home/enquire-button.gif">
                    </a>
                    







                    <style>
                      .float {
                        position: fixed;
                        width: 200px;
                        bottom: 30px;
                        right: 20px;
                        color: #FFF;
                        border-radius: 50px;
                        text-align: center;
                        font-size: 30px;
                        z-index: 111103;
                      }

                      .my-float {
                        margin-top: 11px;
                      }

                      .float1 {
                        position: fixed;
                        width: 60px;
                        height: 60px;
                        bottom: 90px;
                        right: 20px;
                        background-color: #25d366;
                        color: #FFF;
                        border-radius: 50px;
                        text-align: center;
                        font-size: 40px;
                        box-shadow: 2px 2px 3px #999;
                        z-index: 111103;
                      }

                      .my-float1 {
                        margin-top: 11px;
                      }

                      .float2 {
                        width: 60px;
                        position: fixed;
                        height: 60px;
                        background-color: #0066FF;
                        bottom: 160px;
                        right: 20px;
                        color: #FFF;
                        border-radius: 50px;
                        text-align: center;
                        font-size: 40px;
                        z-index: 111103;
                      }

                      .my-float2 {
                        margin-top: 11px;
                      }

                      .fix-icon-whataap {
                        display: inline-block;
                        position: fixed;
                        bottom: 30px;
                        left: 20px;
                        z-index: 999999;
                        transition: all0.5s ease-in-out;
                      }

                      .fix-icon-whataap-item img {
                        border-radius: 50%;
                        box-shadow: 1px 1px 4px rgba(60, 60, 60, .4);
                        transition: box-shadow .2s;
                        cursor: pointer;
                        overflow: hidden;
                        width: 55px !important;
                        height: 55px !important;
                        background: #25d366 !important;
                      }

                      #fix-icon-whataap {
                        -webkit-animation-duration: 2.5s;
                        animation-duration: 2.5s;
                        -webkit-animation-fill-mode: both;
                        animation-fill-mode: both;
                        -webkit-animation-timing-function: linear;
                        animation-timing-function: linear;
                        animation-iteration-count: infinite;
                        -webkit-animation-iteration-count: infinite;
                      }

                      .fix-icon-whataap {
                        animation: bounce 1s infinite alternate;
                        animation-duration: 1s;
                        -webkit-animation: bounce 1s infinite alternate;
                        animation-duration: 1s;
                        animation-timing-function: ease;
                        animation-iteration-count: infinite;
                        animation-fill-mode: none;
                      }

                      a.text-white.bg-purple-700.hover\:bg-purple-800.focus\:ring-4.focus\:ring-purple-300.font-medium.rounded-lg.text-sm.px-4.lg\:px-5.py-2.lg\:py-2\.5.sm\:mr-2.lg\:mr-0.dark\:bg-purple-600.dark\:hover\:bg-purple-700.focus\:outline-none.dark\:focus\:ring-purple-800 {
                        background: orange;
                      }
                    </style>

                    
<script src="https://unpkg.com/flowbite@1.4.1/dist/flowbite.js"></script>                  </section>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </section>
  </section>
</body>

</html>